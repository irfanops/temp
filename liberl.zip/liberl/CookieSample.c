#include<stdio.h>
#include<stdint.h>
#include <inttypes.h>
#include "CookieSampleJNI.h"
#include<jni.h>
#define MIX(a,b,c)                 \
do {                               \
    a -= b; a -= c; a ^= (c>>13);    \
    b -= c; b -= a; b ^= (a<<8);     \
    c -= a; c -= b; c ^= (b>>13);    \
    a -= b; a -= c; a ^= (c>>12);    \
    b -= c; b -= a; b ^= (a<<16);    \
    c -= a; c -= b; c ^= (b>>5);     \
    a -= b; a -= c; a ^= (c>>3);     \
    b -= c; b -= a; b ^= (a<<10);    \
    c -= a; c -= b; c ^= (b>>15);    \
} while(0)

#define HCONST 0x9e3779b9UL
#define HCONST_13 0x08d12e65UL

uint32_t block_hash(char* k, uint32_t length, uint32_t initval)
{
    uint32_t a,b,c;
    uint32_t len;

    /* Set up the internal state */
    len = length;
    a = b = (uint32_t)HCONST;
    c = initval;           /* the previous hash value */

    while (len >= 12)
    {
        a += (k[0] +((uint32_t)k[1]<<8) +((uint32_t)k[2]<<16) +((uint32_t)k[3]<<24));
        b += (k[4] +((uint32_t)k[5]<<8) +((uint32_t)k[6]<<16) +((uint32_t)k[7]<<24));
        c += (k[8] +((uint32_t)k[9]<<8) +((uint32_t)k[10]<<16)+((uint32_t)k[11]<<24));
        MIX(a,b,c);
        k += 12; len -= 12;
    }

    c += length;
    switch(len)              /* all the case statements fall through */
    {
        case 11: c+=((uint32_t)k[10]<<24);
        case 10: c+=((uint32_t)k[9]<<16);
        case 9 : c+=((uint32_t)k[8]<<8);
                 /* the first byte of c is reserved for the length */
        case 8 : b+=((uint32_t)k[7]<<24);
        case 7 : b+=((uint32_t)k[6]<<16);
        case 6 : b+=((uint32_t)k[5]<<8);
        case 5 : b+=k[4];
        case 4 : a+=((uint32_t)k[3]<<24);
        case 3 : a+=((uint32_t)k[2]<<16);
        case 2 : a+=((uint32_t)k[1]<<8);
        case 1 : a+=k[0];
                 /* case 0: nothing left to add */
    }
    MIX(a,b,c);
    return c;
}

uint32_t make_hash2(char* k, uint32_t len)
{
    uint32_t hash = 0;
    uint32_t con = (uint32_t)HCONST_13 + hash; 
    return block_hash(k,len,con);
}

JNIEXPORT jlong JNICALL Java_presto_udfs_scalar_CookieSample_pHash2(JNIEnv *env, jobject obj, jbyteArray arr, jint slots)
{
    jboolean isCopy;
    jsize l = (*env)->GetArrayLength(env,arr);
    jbyte* b = (*env)->GetByteArrayElements(env,arr,&isCopy);

    char* k = (char *) b;
    uint32_t len = (uint32_t) l;
    uint32_t hash = make_hash2(k,len);
    uint32_t final_hash = hash % slots;

    (*env)->ReleaseByteArrayElements(env,arr,b,0);
    return (jlong) final_hash;
}

