#!/bin/bash

ICINGA_HOSTNAME="icinga.internal.adroll.com"
SLACK_WEBHOOK_URL="https://hooks.slack.com/services/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"
SLACK_CHANNEL="dev_solutionseng"
SLACK_BOTNAME="Icinga"

#Set the message icon based on ICINGA Host state
if [ "$HOSTSTATE" = "DOWN" ]
then
    ICON=":red_circle:"
elif [ "$HOSTSTATE" = "UP" ]
then
    ICON=":white_check_mark:"
else
    ICON=":question:"
fi

#Send message to Slack
PAYLOAD="payload={\"channel\": \"${SLACK_CHANNEL}\", \"username\": \"${SLACK_BOTNAME}\", \"text\": \"[*$NOTIFICATIONTYPE]*\n\n *HOST:* <https://${ICINGA_HOSTNAME}/monitoring/host/show?host=${HOSTNAME}|${HOSTDISPLAYNAME}>    *STATE:* ${HOSTSTATE} ${ICON}\n\n *Address:* $HOSTADDRESS\n\n *Date/Time:* $LONGDATETIME\n\n *Additional Info:* ${HOSTOUTPUT}\n\n *Comment:* [$NOTIFICATIONAUTHORNAME] $NOTIFICATIONCOMMENT\"}"


curl --connect-timeout 30 --max-time 60 -s -S -X POST --data-urlencode "${PAYLOAD}" "${SLACK_WEBHOOK_URL}"
