#!/bin/bash

ICINGA_HOSTNAME="icinga.internal.adroll.com"
SLACK_WEBHOOK_URL="https://hooks.slack.com/services/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"
SLACK_CHANNEL="noc_alerts"
SLACK_BOTNAME="Icinga"

#Set the message icon based on ICINGA service state
if [ "$SERVICESTATE" = "CRITICAL" ]
then
    ICON=":exclamation:"
elif [ "$SERVICESTATE" = "WARNING" ]
then
    ICON=":warning:"
elif [ "$SERVICESTATE" = "OK" ]
then
    ICON=":white_check_mark:"
elif [ "$SERVICESTATE" = "UNKNOWN" ]
then
    ICON=":question:"
else
    ICON=":white_medium_square:"
fi

#Send message to Slack
PAYLOAD="payload={\"channel\": \"${SLACK_CHANNEL}\", \"username\": \"${SLACK_BOTNAME}\", \"text\": \"*[$NOTIFICATIONTYPE*]  *SERVICE:* <https://${ICINGA_HOSTNAME}/monitoring/service/show?host=${HOSTNAME}&service=${SERVICEDESC}|${SERVICEDISPLAYNAME}>    *STATE:* ${SERVICESTATE} ${ICON}    *HOST:* <https://${ICINGA_HOSTNAME}/monitoring/host/show?host=${HOSTNAME}|${HOSTDISPLAYNAME}>\n\n *Date/Time:* $LONGDATETIME\n\n *Additional Info:* $SERVICEOUTPUT\n\n *Comment:* [$NOTIFICATIONAUTHORNAME] $NOTIFICATIONCOMMENT\"}"

curl --connect-timeout 30 --max-time 60 -s -S -X POST --data-urlencode "${PAYLOAD}" "${SLACK_WEBHOOK_URL}"
