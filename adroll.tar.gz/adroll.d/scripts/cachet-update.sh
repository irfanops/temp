#!/bin/bash

/usr/lib64/nagios/plugins/cachet_notify "Test Server" "$HOSTALIAS" "$HOSTSTATE" "$HOSTSTATETYPE" "$HOSTOUTPUT"

