SELECT
        a.advertisable_eid,
        a.country,
        a.region,
        a.subregion,
        COALESCE(c.final_vertical, a.vertical) AS vertical,
        c.industry,
        a.revshare_view_percent,
        a.revshare_click_percent,
        b.iab1_category_name,
        b.iab2_category_name,
        b.zvelo_category_name,
        d.min_alexa_rank,
        a.view_through_conversion_window,
        a.click_through_conversion_window,
        CAST(b.created_date AS varchar) AS created_date,
        a.date
    FROM bi.advertisable_metadata_snapshots AS a
        INNER JOIN db.public.advertisables AS b
            ON a.advertisable_eid = b.eid
        LEFT JOIN bi.marketing_vertical_mapping as c
            ON CASE WHEN (a.vertical = '' OR a.vertical IS NULL)
                    THEN '-none-' 
                    ELSE lower(a.vertical) end = c.initial_vertical
        LEFT JOIN bi.salesforce_account AS d
            ON d.organization_eid = a.organization_eid
    WHERE date = '2018-04-15'