WITH ecomm AS
(SELECT DISTINCT advertisable
FROM (SELECT advertisable FROM shopify.public.shopify_users
UNION SELECT advertisable FROM shopify.public.woocommerce_users
UNION SELECT advertisable FROM shopify.public.prestashop_users
UNION SELECT advertisable FROM shopify.public.magento_users))

SELECT delivery.advertisable_eid,
date,
total_spend as dynamic_spend
FROM bi.product_delivery delivery
JOIN ecomm ON ecomm.advertisable = delivery.advertisable_eid
WHERE product = 'dynamic_ads_overall'
AND delivery.date >= cast('2016-11-01' as date)