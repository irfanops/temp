    WITH 
    EXCHANGE_RATES AS
        (SELECT
            ALL_CURRENCIES.currency,
            ALL_CURRENCIES.rate
        FROM
            (SELECT
                currency,
                rate,
                ROW_NUMBER() OVER (PARTITION BY currency ORDER BY effective_date DESC) AS rk
            FROM db.public.exchange_rates) AS ALL_CURRENCIES
        WHERE ALL_CURRENCIES.rk = 1),

    VOL_CMP_GOAL_MAP AS (
        SELECT
            c.eid AS campaign_eid,
            COALESCE(b.kpi_metric, a.kpi_metric) AS campaign_goal_metric,
            COALESCE(b.kpi_goal, a.kpi_goal) * COALESCE(d.rate, 1) AS campaign_goal_value,
            'voltron' AS campaign_goal_inheritance
        FROM voltron.public.strategies AS a
            JOIN voltron.public.strategy_campaign_groups AS b
                ON a.id = b.strategy_id
            JOIN voltron.public.strategy_campaigns AS c
                ON a.id = c.strategy_id
            JOIN EXCHANGE_RATES AS d
                ON a.currency = d.currency
        WHERE template NOT IN ('rakuten')
    ),

    -- Currently, campaign_goal_metric is set AS 'Spend' when MyCroft is
    -- enabled, so we go ahead and climb upwards if we have an uninformative
    -- campaign level goal. Now that KPI goals have been decoupled, we will need
    -- to adjust this later.
    CURRENT_CMP_GOALS AS
    (SELECT
       advertisable_eid,
       a.campaign_eid,
       COALESCE(b.campaign_goal_metric, a.campaign_goal_metric) AS campaign_goal_metric,
       COALESCE(b.campaign_goal_value, a.campaign_goal_value) AS campaign_goal_value,
       COALESCE(b.campaign_goal_inheritance, a.campaign_goal_inheritance) AS campaign_goal_inheritance,
       is_mycroft_enabled
     FROM
      (SELECT
            advertisable_eid,
            campaign_eid,
            goal_metric AS campaign_goal_metric,
            goal_value AS campaign_goal_value,
            goal_inheritance AS campaign_goal_inheritance,
            is_mycroft_enabled,
            RANK() OVER (PARTITION BY campaign_eid ORDER BY date DESC) AS rk
       FROM optilab.cmp_goal_map AS a
       WHERE date > TRY_CAST((current_date - interval '7' day) AS VARCHAR)
      ) AS a
        LEFT JOIN VOL_CMP_GOAL_MAP AS b
            ON a.campaign_eid = b.campaign_eid
      WHERE rk = 1
    ),

    CURRENT_ADV_ATTRIBUTION AS
      (SELECT
        eid AS advertisable_eid,
        name AS advertisable_name,
        revshare_view_percent,
        view_through_conversion_window,
        revshare_click_percent,
        click_through_conversion_window
      FROM db.public.advertisables
    ),

    MYCROFT_CAMPAIGNS AS
        (SELECT DISTINCT campaign_eid
        FROM mycroft_levers.public.enabled_campaigns
        WHERE is_active AND is_enabled),

    MYCROFT_LEVERS AS
        (SELECT DISTINCT
            LEVERS.campaign_eid,
            LEVERS.metric AS mycroft_lever_metric,
            LEVERS.goal*COALESCE(exchange_rates.rate,1) AS mycroft_goal_usd,
            LEVERS.currency_code AS mycroft_goal_currency_code,
            LEVERS.goal AS mycroft_goal_local_currency
        FROM
            (SELECT
                campaign_eid,
                currency_code,
                metric,
                (CASE WHEN metric = 'Spend' THEN 0 ELSE goal END) AS goal
            FROM mycroft_levers.public.performance_targets
            WHERE is_active) AS LEVERS
        LEFT JOIN EXCHANGE_RATES
        ON LEVERS.currency_code = EXCHANGE_RATES.currency),

    WINDOW_CMP_PERFORMANCE AS
    (SELECT
      CM.advertisable_eid,
      CM.campaign_eid,
      campaign_goal_metric,
      campaign_goal_value,
      campaign_goal_inheritance,
      eod_budget,
      spend / (impressions/1000.0) AS cpm,
      clicks / impressions AS ctr,
      1.0*(spend) / clicks AS cpc,
      spend / (ctcs*CURRENT_ADV_ATTRIBUTION.revshare_click_percent +
               vtcs*CURRENT_ADV_ATTRIBUTION.revshare_view_percent) AS cpa,
      spend / (ctcs*CURRENT_ADV_ATTRIBUTION.revshare_click_percent) AS click_cpa,
      (ctc_rev*CURRENT_ADV_ATTRIBUTION.revshare_click_percent +
       vtc_rev*CURRENT_ADV_ATTRIBUTION.revshare_view_percent) / spend AS roi,
      (ctc_rev*CURRENT_ADV_ATTRIBUTION.revshare_click_percent) / spend AS click_roi,
      1.0*spend/eod_budget AS fulfillment,
      spend / new AS cpnv,
      spend / engaged AS cpev,
      mycroft_lever_metric,
      mycroft_goal_usd,
      mycroft_goal_currency_code,
      mycroft_goal_local_currency
    FROM optilab.cmp_metrics_30 CM
    LEFT JOIN CURRENT_CMP_GOALS
      ON CM.campaign_eid = CURRENT_CMP_GOALS.campaign_eid
    LEFT JOIN
      CURRENT_ADV_ATTRIBUTION
      ON CURRENT_ADV_ATTRIBUTION.advertisable_eid =
         CURRENT_CMP_GOALS.advertisable_eid
    LEFT JOIN MYCROFT_LEVERS
        ON CM.campaign_eid = MYCROFT_LEVERS.campaign_eid
    WHERE CM.date = '2018-04-15'
    ),

    -- Choose the relevant KPI and convert it into 'bigger-is-better' version
    -- Creates `cmp_kpi_goal_value, `cmp_kpi_inheritance`, `window_cmp_kpi_value`
    WINDOW_CMP_KPI AS
    (SELECT
      advertisable_eid,
      campaign_eid,
      cpm,
      ctr,
      cpc,
      cpa,
      click_cpa,
      roi,
      click_roi,
      fulfillment,
      cpev,
      cpnv,
      campaign_goal_inheritance AS kpi_inheritance,
      campaign_goal_metric AS kpi_metric,
      CASE campaign_goal_metric
        WHEN 'CPC'       THEN campaign_goal_value
        WHEN 'CPA'       THEN campaign_goal_value
        WHEN 'Click CPA' THEN campaign_goal_value
        WHEN 'CPM'       THEN campaign_goal_value
        WHEN 'Spend'     THEN eod_budget
        ELSE campaign_goal_value
      END AS kpi_goal_value,
      CASE campaign_goal_metric
        WHEN 'CPC'       THEN cpc
        WHEN 'CPA'       THEN cpa
        WHEN 'Click CPA' THEN click_cpa
        WHEN 'CPM'       THEN cpm
        WHEN 'CTR'       THEN ctr
        WHEN 'ROI'       THEN roi
        WHEN 'Click ROI' THEN click_roi
        WHEN 'Spend'     THEN fulfillment
        WHEN 'CPNV'      THEN cpnv
        WHEN 'CPEV'      THEN cpev
        ELSE 0
      END AS kpi_value,
      mycroft_lever_metric AS mycroft_kpi_metric,
      CASE mycroft_lever_metric
        WHEN 'CPC'       THEN mycroft_goal_usd
        WHEN 'CPA'       THEN mycroft_goal_usd
        WHEN 'Click CPA' THEN mycroft_goal_usd
        WHEN 'CPM'       THEN mycroft_goal_usd
        WHEN 'Spend'     THEN eod_budget
        ELSE mycroft_goal_usd
      END AS mycroft_kpi_goal_value,
      CASE mycroft_lever_metric
        WHEN 'CPC'       THEN cpc
        WHEN 'CPA'       THEN cpa
        WHEN 'Click CPA' THEN click_cpa
        WHEN 'CPM'       THEN cpm
        WHEN 'CTR'       THEN ctr
        WHEN 'ROI'       THEN roi
        WHEN 'Click ROI' THEN click_roi
        WHEN 'Spend'     THEN fulfillment
        WHEN 'CPNV'      THEN cpnv
        WHEN 'CPEV'      THEN cpev
        ELSE 0
      END AS mycroft_kpi_value
      FROM WINDOW_CMP_PERFORMANCE
    ),

    FINAL_TABLE AS
    (SELECT
      advertisable_eid,
      campaign_eid,
      cpm,
      ctr,
      cpc,
      cpa,
      click_cpa,
      roi,
      click_roi,
      cpnv,
      cpev,
      fulfillment,
      kpi_inheritance,
      kpi_metric,
      kpi_goal_value,
      CASE
        WHEN IS_NAN(kpi_value)
        THEN NULL
        ELSE kpi_value
      END AS kpi_value,
      CASE kpi_metric
        WHEN 'CPC'       THEN kpi_goal_value / cpc
        WHEN 'CPA'       THEN kpi_goal_value / cpa
        WHEN 'Click CPA' THEN kpi_goal_value / click_cpa
        WHEN 'CPM'       THEN kpi_goal_value / cpm
        WHEN 'CTR'       THEN ctr / kpi_goal_value
        WHEN 'ROI'       THEN roi / kpi_goal_value
        WHEN 'Click ROI' THEN click_roi / kpi_goal_value
        WHEN 'Spend'     THEN fulfillment
        WHEN 'CPNV'       THEN kpi_goal_value / cpnv
        WHEN 'CPEV'       THEN kpi_goal_value / cpev
        ELSE 0.000
      END AS perf_vs_goal,
      mycroft_kpi_metric,
      mycroft_kpi_goal_value,
      CASE
        WHEN IS_NAN(mycroft_kpi_value)
        THEN NULL
        ELSE mycroft_kpi_value
      END AS mycroft_kpi_value,
      CASE mycroft_kpi_metric
        WHEN 'CPC'       THEN mycroft_kpi_goal_value / cpc
        WHEN 'CPA'       THEN mycroft_kpi_goal_value / cpa
        WHEN 'Click CPA' THEN mycroft_kpi_goal_value / click_cpa
        WHEN 'CPM'       THEN mycroft_kpi_goal_value / cpm
        WHEN 'CTR'       THEN ctr / mycroft_kpi_goal_value
        WHEN 'ROI'       THEN roi / mycroft_kpi_goal_value
        WHEN 'Click ROI' THEN click_roi / mycroft_kpi_goal_value
        WHEN 'Spend'     THEN fulfillment
        WHEN 'CPNV'       THEN mycroft_kpi_goal_value / cpnv
        WHEN 'CPEV'       THEN mycroft_kpi_goal_value / cpev
        ELSE 0.000
      END AS mycroft_perf_vs_goal
    FROM
      WINDOW_CMP_KPI
    )

    -- MAIN (Handle missing and infinite values)
    SELECT
      TRY_CAST(to_unixtime(current_timestamp) AS BIGINT) AS generation_timestamp,
      advertisable_eid,
      campaign_eid,
      COALESCE(cpm, 0) AS cpm,
      COALESCE(ctr, 0) AS ctr,
      COALESCE(cpc, 0) AS cpc,
      COALESCE(cpa, 0) AS cpa,
      COALESCE(click_cpa, 0) AS click_cpa,
      COALESCE(roi, 0) AS roi,
      COALESCE(click_roi, 0) AS click_roi,
      kpi_metric,
      kpi_goal_value,
      kpi_inheritance,
      kpi_value,
      CASE
        WHEN is_finite(fulfillment) THEN fulfillment
        ELSE 0
      END AS budget_fulfillment,
      CASE
        WHEN (is_finite(perf_vs_goal)
              AND kpi_metric = 'Spend'
              AND kpi_value > 1) THEN 1.0
        WHEN is_finite(perf_vs_goal) THEN perf_vs_goal
        ELSE 0
      END AS perf_vs_goal,
      COALESCE(cpnv, 0) AS cpnv,
      COALESCE(cpev, 0) AS cpev,
      mycroft_kpi_metric,
      mycroft_kpi_goal_value,
      mycroft_kpi_value,
      CASE
        WHEN (is_finite(mycroft_perf_vs_goal)
            AND mycroft_kpi_metric = 'Spend'
            AND mycroft_kpi_value > 1) THEN 1.0
        WHEN is_finite(mycroft_perf_vs_goal) THEN mycroft_perf_vs_goal
        ELSE 0
      END AS mycroft_perf_vs_goal

    FROM
      FINAL_TABLE