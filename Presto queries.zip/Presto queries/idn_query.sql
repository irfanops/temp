SELECT cookie
FROM hive.adroll.log_lines
WHERE line_type = 'idn'
AND stable_user_identifier = 'f6b07e62fed1179954e56921ea4098e4'
  AND date='2016-03-24' LIMIT 5