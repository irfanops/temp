SELECT
	distinct users.eid,
   'dormant_shopify_users' as event,
   users.email as email,
   meta.advertisable_eid as advertisable_eid,
   hc_adv.last30_list_size as list_size
   
FROM shopify.public.shopify_users shopify
JOIN bi.advertisable_metadata meta on meta.advertisable_eid=shopify.advertisable
JOIN bi.hc_advertisable hc_adv on hc_adv.advertisable_eid=meta.advertisable_eid
JOIN db.public.advertisables adv ON adv.eid = meta.advertisable_eid
JOIN db.public.organizations orgs ON orgs.id = adv.organization_id
JOIN db.public.users users ON users.organization_id = orgs.id

WHERE 
shopify.status='app_installed'
AND meta.created_date >= (current_date - interval '17' day)
AND meta.created_date <= (current_date - interval '16' day)
AND meta.initial_spend_date is null
AND hc_adv.last30_list_size between 1000 and 40000
AND (meta.ops_department LIKE '%Emerging%' or meta.ops_department is null)
AND users.email NOT LIKE '%adroll.com'
AND users.email NOT LIKE '%springbot.com'
AND users.email NOT LIKE '%mediamint.com'
AND users.is_active=true
AND users.organization_role = 'admin'
AND users.locale like '%en%'
AND orgs.eid IN (SELECT orgs.eid
                    FROM db.public.advertisables adv
                    JOIN db.public.organizations orgs ON orgs.id = adv.organization_id
                    GROUP BY 1
                    HAVING count(distinct adv.eid) < 4)
AND orgs.eid NOT IN (SELECT organization_eid
                    FROM bi.advertisable_metadata
                    WHERE last_spend_date >= (current_date - interval '30' day))