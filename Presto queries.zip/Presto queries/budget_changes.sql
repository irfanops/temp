WITH recent_adroll_budget_changes AS
  (SELECT campaign_eid,
         create_date as created_date,
          advertisable_eid,
          user_email
   FROM
     (SELECT DATE_FORMAT(TRY_CAST(C.created_date AS date), '%Y-%m-%d') create_date,
                                                                       A.eid AS advertisable_eid,
                                                                       CMP.eid AS campaign_eid,
                                                                       U.eid AS user_eid,
                                                                       U.email AS user_email,
                                                                       c.*,
                                                                       RANK() OVER (PARTITION BY A.eid, CMP.eid
                                                                                    ORDER BY C.created_date) AS rk
      FROM db.public.changes C
      JOIN db.public.campaigns CMP ON CMP.id = C.row_id
      JOIN db.public.advertisables A ON CMP.advertisable_id = A.id
      JOIN db.public.users U ON U.id = C.user_id
      WHERE C."table" = 'campaigns'
        AND C.column = 'budget'
        AND C.old_value <> C.new_value
        AND CAST(C.created_date AS VARCHAR) BETWEEN '2017-11-22' AND '2017-11-28'
        AND U.email NOT IN ('optilab@adroll.com',
                            'bibin.mathew@adroll.com',
                            'ike.okonkwo@adroll.com',
                            'alex.leu@adroll.com',
                            'asif.imran@adroll.com',
                            'alex.rhee@adroll.com'))
   WHERE rk = 1
   GROUP BY 1,
            2,3,4),
      recent_pr_budget_changes AS
  (SELECT campaign_eid,
          created_Date,
                    advertisable_eid,
          user_email
   FROM
     (SELECT DATE_FORMAT(TRY_CAST(PE.created_at AS DATE), '%Y-%m-%d') AS created_date,
             CMP.advertisable AS advertisable_eid,
             CMP.eid AS campaign_eid,
             PE.user_eid AS user_eid,
             U.email AS user_email,
             RANK() OVER (PARTITION BY CMP.advertisable, CMP.eid
                          ORDER BY created_date) AS rk
      FROM prospecting.public.prospecting_events PE
      JOIN prospecting.public.prospecting_campaigns CMP ON CMP.id = PE.campaign_id
      JOIN db.public.users U ON U.eid = PE.user_eid
      WHERE cast(PE.created_at AS varchar) BETWEEN '2017-11-22' AND '2017-11-28'
        AND PE."type" = 'campaign_budget_change'
        AND U.email NOT IN ('optilab@adroll.com',
                            'bibin.mathew@adroll.com',
                            'ike.okonkwo@adroll.com',
                            'alex.leu@adroll.com',
                            'asif.imran@adroll.com',
                            'alex.rhee@adroll.com'))
   WHERE rk = 1),
      recent_c4g_budget_changes AS
  (SELECT campaign_eid,
          created_date,
         advertisable_eid,
          event_data as user_email
   FROM
     (SELECT DATE_FORMAT(CE.created_date, '%Y-%m-%d') AS created_date,
             adv.eid AS advertisable_eid,
             CMP.eid AS campaign_eid,
             CE.event_data,
             RANK() OVER (PARTITION BY CMP.advertiser_id, CMP.eid
                          ORDER BY CE.created_date) AS rk
      FROM cats4gold.public.events CE
      JOIN cats4gold.public.adsets a ON a.eid = CE.object_eid
      JOIN cats4gold.public.campaigns CMP ON CMP.id = a.campaign_id
      JOIN cats4gold.public.advertisers AS adv ON CMP.advertiser_id = adv.id
      WHERE CAST(CE.created_date AS varchar) BETWEEN '2017-11-22' AND '2017-11-28'
        AND CE.event_data LIKE '%budget%'
        AND CE.event_data NOT LIKE '%optilab@adroll.com%')
   WHERE rk = 1)
SELECT *
FROM
  (SELECT campaign_eid,
          created_date,
                    advertisable_eid,
          user_email
   FROM recent_adroll_budget_changes
   UNION SELECT campaign_eid,
                created_date,
                          advertisable_eid,
          user_email
   FROM recent_pr_budget_changes
   UNION SELECT campaign_eid,
                created_date,
                          advertisable_eid,
          user_email
   FROM recent_c4g_budget_changes)
WHERE advertisable_eid in ('56FKQEGDVVBQZFTR5VDUJQ', 'PPUUCHMYXJBGDGFZZFH6HK', 'HGAM45IRB5GXVJPUZ3AIJV')