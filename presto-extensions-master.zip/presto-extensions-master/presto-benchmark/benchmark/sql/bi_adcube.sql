SELECT 
    CAST(COALESCE(raw_logs.day_by_hour,joined_logs.day_by_hour) AS VARCHAR) AS date_by_hour,
    (CASE WHEN LENGTH(COALESCE(raw_logs.ad_eid, joined_logs.ad_eid)) = 22 
        THEN COALESCE(raw_logs.ad_eid, joined_logs.ad_eid)
        ELSE '' END) AS ad_eid, 
    (CASE WHEN LENGTH(COALESCE(raw_logs.adgroup_eid, joined_logs.adgroup_eid)) = 22 
        THEN COALESCE(raw_logs.adgroup_eid, joined_logs.adgroup_eid)
        ELSE '' END) AS adgroup_eid, 
    (CASE WHEN LENGTH(COALESCE(adgroup_campaign.campaign_eid, raw_logs.campaign_eid, joined_logs.campaign_eid)) = 22 
        THEN COALESCE(adgroup_campaign.campaign_eid, raw_logs.campaign_eid, joined_logs.campaign_eid)
        ELSE '' END) AS campaign_eid, 
    adgroup_campaign.advertisable_eid,
    (CASE WHEN LENGTH(COALESCE(raw_logs.segment_eid, joined_logs.segment_eid)) = 22 
        THEN COALESCE(raw_logs.segment_eid, joined_logs.segment_eid)
        ELSE '' END) AS segment_eid,
    (CASE 
        WHEN COALESCE(raw_logs.network, joined_logs.network) = 'opx' THEN 'o'
        WHEN COALESCE(raw_logs.network, joined_logs.network) = 'cci' THEN 'c'
        WHEN COALESCE(raw_logs.network, joined_logs.network)
        in ('a','g','i','o','c','m','b','t','r','x','f','w','l','u','d','n','index')
        THEN COALESCE(raw_logs.network, joined_logs.network)
        ELSE '' END) AS network,
    (CASE WHEN COALESCE(raw_logs.inventory_source, joined_logs.inventory_source)
        in ('c','r','m','h','f','i')
        THEN COALESCE(raw_logs.inventory_source, joined_logs.inventory_source)
        ELSE '' END) AS inventory_source,
    (CASE WHEN LENGTH(COALESCE(raw_logs.geo_country_code3, joined_logs.geo_country_code3)) <= 3 
        THEN COALESCE(raw_logs.geo_country_code3, joined_logs.geo_country_code3)
        ELSE '' END) AS country, 
    COALESCE((CAST(db.public.ad_formats.width AS VARCHAR)||'x'||CAST(db.public.ad_formats.height AS VARCHAR)), 
        ((CASE WHEN TRY_CAST(TRY_CAST(raw_logs.width AS BIGINT) AS VARCHAR) = '0'
            THEN NULL ELSE TRY_CAST(TRY_CAST(raw_logs.width AS BIGINT) AS VARCHAR) END)
        ||'x'||
        (CASE WHEN TRY_CAST(TRY_CAST(raw_logs.height AS BIGINT) AS VARCHAR) = '0'
            THEN NULL ELSE TRY_CAST(TRY_CAST(raw_logs.height AS BIGINT) AS VARCHAR) END)),
        ((CASE WHEN TRY_CAST(TRY_CAST(joined_logs.width AS BIGINT) AS VARCHAR) = '0'
            THEN NULL ELSE TRY_CAST(TRY_CAST(joined_logs.width AS BIGINT) AS VARCHAR) END)
        ||'x'||
        (CASE WHEN TRY_CAST(TRY_CAST(joined_logs.height AS BIGINT) AS VARCHAR) = '0'
            THEN NULL ELSE TRY_CAST(TRY_CAST(joined_logs.height AS BIGINT) AS VARCHAR) END))) AS ad_size,
    COALESCE(raw_logs.operating_system,joined_logs.operating_system) AS operating_system,
    COALESCE(raw_logs.browser,joined_logs.browser) AS browser,
    CAST(SUM(raw_logs.bids) AS DOUBLE) AS bids,
    SUM(raw_logs.bid_cpm) AS bid_cpm,
    SUM(raw_logs.bid_sqpug_probability) AS bid_sqpug_probability,
    SUM(joined_logs.total_spend) AS total_spend,
    SUM(joined_logs.total_cost) AS total_cost,
    SUM(joined_logs.network_cost) AS network_cost,
    SUM(joined_logs.liquid_cost) AS liquid_cost,
    SUM(joined_logs.evidon_cost) AS evidon_cost,
    SUM(joined_logs.data_cost) AS data_cost,
    SUM(joined_logs.additional_cost) AS additional_cost,
    SUM(joined_logs.win_sqpug_probability) AS win_sqpug_probability,
    SUM(joined_logs.win_cpm) AS win_cpm,
    SUM(joined_logs.impressions) AS impressions,
    SUM(joined_logs.clicks) AS clicks,
    SUM(joined_logs.vtcs) AS vtcs,
    SUM(CASE WHEN joined_logs.currency = 'USC' OR joined_logs.currency = '' THEN joined_logs.vtc_rev/100
      ELSE joined_logs.vtc_rev * COALESCE(exchange_rates.rate,1) END) as vtc_rev,
    SUM(joined_logs.ctcs) AS ctcs,
    SUM(CASE WHEN joined_logs.currency = 'USC' OR joined_logs.currency = '' THEN joined_logs.ctc_rev/100
      ELSE joined_logs.ctc_rev * COALESCE(exchange_rates.rate,1) END) as ctc_rev
FROM
    (SELECT 
        DATE_TRUNC('hour',FROM_UNIXTIME(joined_log_lines.timestamp)) AS day_by_hour,
        joined_log_lines.ad_eid,
        joined_log_lines.adgroup_eid,
        joined_log_lines.campaign_eid,
        joined_log_lines.segment_eid,
        joined_log_lines.network,
        joined_log_lines.inventory_source,
        joined_log_lines.geo_country_code3,
        joined_log_lines.width,
        joined_log_lines.height,
        PARSE_UA(joined_log_lines.user_agent)['os'] AS operating_system,
        PARSE_UA(joined_log_lines.user_agent)['user_agent'] AS browser,
        joined_log_lines.currency,
        SUM(joined_log_lines.cost)/1e6 AS total_spend,
        SUM(joined_log_lines.our_cost)/1e6 AS total_cost,
        SUM(joined_log_lines.evidon_cost)/1e6 AS evidon_cost,
        SUM(joined_log_lines.data_cost)/1e6 AS data_cost,
        SUM(joined_log_lines.additional_cost)/1e6 AS additional_cost,
        SUM(joined_log_lines.liquid_cost)/1e6 AS liquid_cost,
        SUM(joined_log_lines.network_cost)/1e6 AS network_cost,
        SUM(CASE WHEN joined_log_lines.type = 'imp' THEN TRY_CAST(joined_log_lines.sqpug_probability AS DOUBLE)/1e9 ELSE 0 END) AS win_sqpug_probability,
        SUM(CASE WHEN joined_log_lines.type = 'imp' THEN TRY_CAST(joined_log_lines.bid_cpm_micros AS DOUBLE)/1e6 ELSE 0 END) AS win_cpm,
        SUM(CASE WHEN joined_log_lines.network = 'f' AND joined_log_lines.inventory_source = 'c' AND joined_log_lines.type = 'imp' THEN TRY_CAST(joined_log_lines.count AS DOUBLE)
                 WHEN (joined_log_lines.network != 'f' OR joined_log_lines.inventory_source != 'c') AND joined_log_lines.type = 'imp' THEN 1 
                 ELSE 0 END) AS impressions,
        SUM(CASE WHEN joined_log_lines.network = 'f' AND joined_log_lines.inventory_source = 'c' AND joined_log_lines.type = 'cli' THEN TRY_CAST(joined_log_lines.count AS DOUBLE)
                 WHEN (joined_log_lines.network != 'f' OR joined_log_lines.inventory_source != 'c') AND joined_log_lines.type = 'cli' THEN 1 
                 ELSE 0 END) AS clicks,
        SUM(CASE WHEN joined_log_lines.type = 'vt2' THEN COALESCE(TRY_CAST(joined_log_lines.count AS DOUBLE),1) ELSE 0 END) as vtcs,
        SUM(CASE WHEN joined_log_lines.type = 'vt2' THEN (TRY_CAST(joined_log_lines.conversion_value AS DOUBLE)*COALESCE(TRY_CAST(joined_log_lines.count AS DOUBLE),1)) ELSE 0 END) AS vtc_rev,
        SUM(CASE WHEN joined_log_lines.type = 'ct2' THEN COALESCE(TRY_CAST(joined_log_lines.count AS DOUBLE),1) ELSE 0 END) as ctcs,
        SUM(CASE WHEN joined_log_lines.type = 'ct2' THEN (TRY_CAST(joined_log_lines.conversion_value AS DOUBLE)*COALESCE(TRY_CAST(joined_log_lines.count AS DOUBLE),1)) ELSE 0 END) AS ctc_rev
    FROM  adroll.joined_log_lines
    WHERE date = '2016-05-01' and filters = ''
    GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13) AS joined_logs
FULL OUTER JOIN
    (SELECT 
        (CASE WHEN log_lines.timestamp > 9999999999 THEN DATE_TRUNC('hour',FROM_UNIXTIME(log_lines.timestamp/1000))
            ELSE DATE_TRUNC('hour',FROM_UNIXTIME(log_lines.timestamp)) END) AS day_by_hour,
        log_lines.ad_eid,
        log_lines.adgroup_eid,
        log_lines.campaign_eid,
        '' as segment_eid,
        log_lines.network,
        log_lines.inventory_source,
        log_lines.geo_country_code3,
        log_lines.width,
        log_lines.height,
        PARSE_UA(CASE log_lines.network
                WHEN 'm' THEN log_lines.mpb_device_user_agent
                WHEN 'o' THEN log_lines.opx_user_agent
                WHEN 'opx' THEN log_lines.opx_user_agent
                WHEN 'c' THEN log_lines.opx_user_agent
                WHEN 'cci' THEN log_lines.opx_user_agent
                WHEN 'r' THEN log_lines.yax_user_agent
                WHEN 'b' THEN log_lines.bsw_device_user_agent
                WHEN 'f' THEN log_lines.fbx_user_agent
                WHEN 'x' THEN log_lines.app_nexus_bid_info_user_agent
                WHEN 'g' THEN log_lines.adx_user_agent
                WHEN 'u' THEN log_lines.uad_device_user_agent
                ELSE '' END)['os'] as operating_system,
        PARSE_UA(CASE log_lines.network
                WHEN 'm' THEN log_lines.mpb_device_user_agent
                WHEN 'o' THEN log_lines.opx_user_agent
                WHEN 'opx' THEN log_lines.opx_user_agent
                WHEN 'c' THEN log_lines.opx_user_agent
                WHEN 'cci' THEN log_lines.opx_user_agent
                WHEN 'r' THEN log_lines.yax_user_agent
                WHEN 'b' THEN log_lines.bsw_device_user_agent
                WHEN 'f' THEN log_lines.fbx_user_agent
                WHEN 'x' THEN log_lines.app_nexus_bid_info_user_agent
                WHEN 'g' THEN log_lines.adx_user_agent
                WHEN 'u' THEN log_lines.uad_device_user_agent
                ELSE '' END)['user_agent'] as browser,
        '' AS currency,
        SUM(CASE WHEN log_lines.inventory_source in ('f','h','r','m') THEN TRY_CAST(log_lines.bid_cpm_micros AS DOUBLE) ELSE 0 END)/1e6 AS bid_cpm,
        SUM(CASE WHEN log_lines.inventory_source in ('f','h','r','m') THEN TRY_CAST(log_lines.sqpug_probability AS DOUBLE) ELSE 0 END)/1e9 AS bid_sqpug_probability,
        SUM(CASE WHEN log_lines.inventory_source in ('f','h','r','m') THEN 1 ELSE 0 END) as bids
    FROM adroll.log_lines
    WHERE line_type = 'bid' AND type = 'bid' AND date = '2016-05-01'
    AND (CASE WHEN timestamp > 9999999999 THEN date_trunc('day',from_unixtime(timestamp/1000))
    ELSE date_trunc('day',from_unixtime(timestamp)) END) = CAST('2016-05-01' AS DATE)
    GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13) AS raw_logs
ON 
    joined_logs.day_by_hour = raw_logs.day_by_hour AND
    joined_logs.ad_eid = raw_logs.ad_eid AND
    joined_logs.adgroup_eid = raw_logs.adgroup_eid AND
    joined_logs.campaign_eid = raw_logs.campaign_eid AND 
    joined_logs.segment_eid = raw_logs.segment_eid AND 
    joined_logs.network = raw_logs.network AND 
    joined_logs.inventory_source = raw_logs.inventory_source AND
    joined_logs.geo_country_code3 = raw_logs.geo_country_code3 AND
    joined_logs.width = raw_logs.width AND
    joined_logs.height = raw_logs.height AND
    joined_logs.operating_system = raw_logs.operating_system AND
    joined_logs.browser = raw_logs.browser AND
    joined_logs.currency = raw_logs.currency
LEFT JOIN
  db.public.ads
ON COALESCE(joined_logs.ad_eid, raw_logs.ad_eid) = db.public.ads.eid
LEFT JOIN
  db.public.ad_formats
ON db.public.ads.ad_format_id = db.public.ad_formats.id
LEFT JOIN
((SELECT 
        db.public.adgroups.eid AS adgroup_eid, 
        db.public.campaigns.eid AS campaign_eid, 
        db.public.advertisables.eid AS advertisable_eid
  FROM 
    db.public.adgroups
  JOIN
    db.public.campaigns
  ON db.public.adgroups.campaign_id = db.public.campaigns.id
  JOIN
    db.public.advertisables
  ON db.public.campaigns.advertisable_id = db.public.advertisables.id)
  UNION DISTINCT
  (SELECT 
        prospecting.public.prospecting_adgroups.eid AS adgroup_eid, 
        prospecting.public.prospecting_campaigns.eid AS campaign_eid, 
        prospecting.public.prospecting_campaigns.advertisable AS advertisable_eid
  FROM
    prospecting.public.prospecting_adgroups
  JOIN
    prospecting.public.prospecting_campaigns
  ON prospecting.public.prospecting_adgroups.campaign_id = prospecting.public.prospecting_campaigns.id)) AS adgroup_campaign
ON COALESCE(joined_logs.adgroup_eid, raw_logs.adgroup_eid) = adgroup_campaign.adgroup_eid
LEFT JOIN
(SELECT all_currencies.currency, all_currencies.rate
FROM
(select currency, rate,
ROW_NUMBER() OVER(PARTITION BY currency ORDER BY effective_date DESC) AS rk FROM
db.public.exchange_rates
WHERE CAST(effective_date as date) <= CAST('2016-05-01' AS date)) AS all_currencies
WHERE all_currencies.rk = 1) as exchange_rates
ON joined_logs.currency = exchange_rates.currency
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12