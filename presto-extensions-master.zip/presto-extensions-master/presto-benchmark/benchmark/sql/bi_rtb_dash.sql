SELECT deliveries.date,
       deliveries.network,
       deliveries.inventory_source,
       deliveries.bidding_strategy,
       deliveries.sqpug_success,
       deliveries.sqpug_version,
       (CASE WHEN sqpug_vcpc < 1 THEN '<$1'
            WHEN sqpug_vcpc >= 1 AND sqpug_vcpc < 2 THEN '$1 - $2'
            WHEN sqpug_vcpc >= 2 AND sqpug_vcpc < 3 THEN '$2 - $3'
            WHEN sqpug_vcpc >= 3 AND sqpug_vcpc < 4 THEN '$3 - $4'
            WHEN sqpug_vcpc >= 4 AND sqpug_vcpc < 5 THEN '$4 - $5'
            WHEN sqpug_vcpc >= 5 AND sqpug_vcpc < 6 THEN '$5 - $6'
            WHEN sqpug_vcpc >= 6 AND sqpug_vcpc < 7 THEN '$6 - $7'
            WHEN sqpug_vcpc >= 7 AND sqpug_vcpc < 8 THEN '$7 - $8'
            WHEN sqpug_vcpc >= 8 AND sqpug_vcpc < 9 THEN '$8 - $9'
            WHEN sqpug_vcpc >= 9 AND sqpug_vcpc < 10 THEN '$9 - $10'
            WHEN sqpug_vcpc >= 10 AND sqpug_vcpc < 11 THEN '$10 - $11'
            WHEN sqpug_vcpc >= 11 AND sqpug_vcpc < 12 THEN '$11 - $12'
            WHEN sqpug_vcpc >= 12 AND sqpug_vcpc < 13 THEN '$12 - $13'
            WHEN sqpug_vcpc >= 13 AND sqpug_vcpc < 14 THEN '$13 - $14'
            WHEN sqpug_vcpc >= 14 AND sqpug_vcpc < 15 THEN '$14 - $15'
            WHEN sqpug_vcpc >= 15 AND sqpug_vcpc < 16 THEN '$15 - $16'
            WHEN sqpug_vcpc >= 16 AND sqpug_vcpc < 17 THEN '$16 - $17'
            WHEN sqpug_vcpc >= 17 AND sqpug_vcpc < 18 THEN '$17 - $18'
            WHEN sqpug_vcpc >= 18 AND sqpug_vcpc < 19 THEN '$18 - $19'
            WHEN sqpug_vcpc >= 19 AND sqpug_vcpc < 20 THEN '$19 - $20'
            WHEN sqpug_vcpc > 20 THEN '>$20'
           ELSE NULL END) AS sqpug_vcpc,
       deliveries.bid_request_result,
       bi.campaign_metadata.vertical,
       bi.campaign_metadata.ops_department,
       bi.campaign_metadata.ops_office,
       bi.campaign_metadata.is_delight_managed,
       SUM(deliveries.total_spend) AS total_spend,
       SUM(deliveries.total_cost) AS total_cost,
       SUM(deliveries.network_cost) AS network_cost,
       SUM(deliveries.liquid_cost) AS liquid_markup,
       SUM(deliveries.bid_requests) AS bid_requests,
       SUM(deliveries.nbrs) AS nbrs,
       SUM(deliveries.nbcs) AS nbcs,
       SUM(deliveries.bids) AS bids,
       SUM(deliveries.bid_sqpug_probability) AS bid_sqpug_probability,
       SUM(deliveries.bid_cpm) AS bid_cpm,
       SUM(deliveries.impressions) AS impressions,
       SUM(deliveries.clicks) AS clicks,
       SUM(deliveries.vtcs) AS vtcs,
       SUM(deliveries.ctcs) AS ctcs,
       max_date.extract_date,
       sum(deliveries.win_cpm) AS win_cpm
FROM bi.rtbcube_strategy AS deliveries
LEFT JOIN bi.campaign_metadata
  ON deliveries.campaign_eid = bi.campaign_metadata.campaign_eid
CROSS JOIN
  (SELECT MAX(date) AS extract_date FROM bi.adcube_network_inventory) AS max_date
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,27