SELECT 
    cookie,
    (CASE WHEN LENGTH(advertisable_eid) = 22 
        THEN advertisable_eid
        ELSE '' END) AS advertisable_eid, 
    (CASE WHEN LENGTH(segment_eid) = 22 
        THEN segment_eid
        ELSE '' END) AS segment_eid,
    (CASE WHEN LENGTH(geo_country_code3) <= 3 
        THEN geo_country_code3
        ELSE '' END) AS country, 
    PARSE_UA(user_agent)['os'] as os,
    PARSE_UA(user_agent)['user_agent'] as browser,
    currency,
    CAST(TRACKABLE(is_trackable, trusted_third_party_cookie) AS VARCHAR) as is_trackable,
    SUM(CASE WHEN line_type = 'pxl' AND type = 'pxl' THEN COALESCE(TRY_CAST(count AS DOUBLE),1) ELSE 0 END) as pxls,
    CAST(0 AS DOUBLE) as dats,
    CAST(0 AS DOUBLE) as mobs,
    SUM(TRY_CAST(conversion_value AS DOUBLE)*COALESCE(TRY_CAST(count AS DOUBLE),1)) AS site_revenue
FROM adroll.log_lines
WHERE line_type ='pxl' AND type = 'pxl' AND date = '2016-05-01'
AND advertisable_eid not in ('KDKBSLOGCVFKJI3UZUGWX6','WLPOO6USHRHRPGL25E2KJD')
GROUP BY 1,2,3,4,5,6,7,8