Presto Benchmark Suite

Steps: Clone repo onto machine and run 

sudo wget "https://repo1.maven.org/maven2/com/facebook/presto/presto-benchmark-driver/0.121/presto-benchmark-driver-0.121-executable.jar" .
sudo wget "https://repo1.maven.org/maven2/com/facebook/presto/presto-cli/0.122/presto-cli-0.122-executable.jar" .

Command to run:
sudo ./presto-benchmark-driver --catalog hive --server <presto_master_node>:8080 --sql sql --suite "bi_cubes" --suite-config suite.json


presto --server <presto_master_node>:8080 --catalog hive --schema default


So this directory should be copied into thing so maybe its worth putting into kiva... lol?

Things to set up:
1. Put benchmark suite into cluster startup


Process when executing:

1. Start up cluster.
2. Ssh into cluster
3. Navigate to benchmark suite directory
4. run sudo ./presto-benchmark-driver --catalog hive --server <presto_master_node>:8080 --sql sql --suite "bi_cubes" --suite-config suite.json (probs dont need all of these options)
5. put these metrics into a file and copy file out of thing
6. ssh out of cluster (logout)
7. terminate_cluster

Also note about the dates in this thingy thing because when running the cube query you need like a date and it'll like yea.t 
