#!/bin/bash
# This file is a wrapper intended to run the benchmark against a default set of queries for bi.

if [ $# -ne 1 ]; then
    echo "Please add an identifier to say which test is this"
    exit 1
else
    TIMESTAMP=$1
fi

PUBLIC_ADDRESS=$(/sbin/ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}')
echo "Running benchmark tool on presto public ip: $PUBLIC_ADDRESS"
sudo chmod +x /mnt/var/presto/plugin/benchmark-suite/presto-benchmark-driver
sudo /mnt/var/presto/plugin/benchmark-suite/presto-benchmark-driver --sql /mnt/var/presto/plugin/benchmark-suite/sql --suite-config /mnt/var/presto/plugin/benchmark-suite/suite.json --catalog hive --server $PUBLIC_ADDRESS:8080 | sudo tee -a ./benchmark.txt

#Copy results to s3
sudo aws s3 cp /mnt/var/presto/plugin/benchmark-suite/benchmark.txt s3://adroll-data/presto/benchmark_result/benchmark_$TIMESTAMP.txt
echo "End on run-benchmark.sh, you can find your results at s3://adroll-data/presto/benchmark_result/benchmark_$TIMESTAMP.txt“
