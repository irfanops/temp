package presto.udfs.scalar;

import com.google.common.base.Charsets;
import io.airlift.slice.Slice;
import io.airlift.slice.Slices;
import org.junit.Test;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileInputStream;

import static org.junit.Assert.assertEquals;

public class TestConversionFunctions
{
    @Test
    public void testEmptyJSON() throws Exception
    {
        String input = "{}";
        byte[] byteInput = input.getBytes();
        Slice emptySlice = Slices.wrappedBuffer(byteInput);
        Slice output = ConversionFunctions.siteHistoryMapping(emptySlice, 1);
        assertEquals("{}", output.toString(Charsets.UTF_8));
    }

    @Test
    public void testNotAJSONInput() throws Exception
    {
        // Must not throw an error but return an empty json
        byte[] byteInput = "NOT A JSON".getBytes();
        Slice emptySlice = Slices.wrappedBuffer(byteInput);
        Slice output = ConversionFunctions.siteHistoryMapping(emptySlice, 1);
        assertEquals("{}", output.toString(Charsets.UTF_8));
    }

    @Test
    public void testExpectedSiteHistoryFormat() throws Exception
    {
        String jsonArrayPath = "src/test/resources/TestJSONSiteHistory.txt";
        try (BufferedReader expectedBuffer = new BufferedReader(
                new InputStreamReader(new FileInputStream(jsonArrayPath)))) {
            String rawJsonInput = expectedBuffer.readLine();
            byte[] byteInput = rawJsonInput.getBytes();
            Slice jsonInput = Slices.wrappedBuffer(byteInput);

            //Actually call the function and create a JSONObject answer
            Slice output = ConversionFunctions.siteHistoryMapping(jsonInput, 1444464552);
            JSONObject jsonObject = new JSONObject(output.toString(Charsets.UTF_8));

            // Expected values for the sample site history
            assertEquals(23, jsonObject.getInt("num_impressions"));
            assertEquals(1, jsonObject.getInt("num_clicks"));
            assertEquals(10000, jsonObject.getLong("conv_seconds_since_first_click"));
            assertEquals(10000, jsonObject.getLong("conv_seconds_since_last_click"));
            assertEquals(713683, jsonObject.getLong("conv_seconds_since_first_imp"));
            assertEquals(10009, jsonObject.getLong("conv_seconds_since_last_imp"));
            assertEquals(703674, jsonObject.getLong("seconds_between_first_last_imp"));
            assertEquals(1443750869, jsonObject.getLong("first_imp_timestamp"));
            assertEquals(1444454543, jsonObject.getLong("last_imp_timestamp"));
            assertEquals("play.google.com", jsonObject.getString("first_domain"));
            assertEquals("play.google.com", jsonObject.getString("last_domain"));
            assertEquals("g", jsonObject.getString("first_network"));
            assertEquals("g", jsonObject.getString("last_network"));
            assertEquals("BV2IRUKOLNBNNBRMOCWSMW", jsonObject.getString("first_ad_eid"));
            assertEquals("BV2IRUKOLNBNNBRMOCWSMW", jsonObject.getString("last_ad_eid"));
            assertEquals("ZCHD5KIIXBCWZMBNN37A3D", jsonObject.getString("first_adgroup_eid"));
            assertEquals("ZCHD5KIIXBCWZMBNN37A3D", jsonObject.getString("last_adgroup_eid"));
            assertEquals("[\"play.google.com\"]", jsonObject.get("distinct_domains").toString());
            assertEquals("[\"g\"]", jsonObject.get("distinct_networks").toString());
            assertEquals("[\"BV2IRUKOLNBNNBRMOCWSMW\"]", jsonObject.get("distinct_ad_eid").toString());
            assertEquals("[\"ZCHD5KIIXBCWZMBNN37A3D\"]", jsonObject.get("distinct_adgroup_eid").toString());
        }
    }

    @Test
    public void testEmptyDomainLogic() throws Exception
    {
        String jsonArrayPath = "src/test/resources/TestMissingDomainsJson.txt";
        try (BufferedReader expectedBuffer = new BufferedReader(
            new InputStreamReader(new FileInputStream(jsonArrayPath)))) {
            String rawJsonInput = expectedBuffer.readLine();
            byte[] byteInput = rawJsonInput.getBytes();
            Slice jsonInput = Slices.wrappedBuffer(byteInput);

            //Actually call the function and create a JSONObject answer
            Slice output = ConversionFunctions.siteHistoryMapping(jsonInput, 1444464552);
            JSONObject jsonObject = new JSONObject(output.toString(Charsets.UTF_8));

            // Expected values for the sample site history
            assertEquals(23, jsonObject.getInt("num_impressions"));
            assertEquals(1, jsonObject.getInt("num_clicks"));
            assertEquals(10000, jsonObject.getLong("conv_seconds_since_first_click"));
            assertEquals(10000, jsonObject.getLong("conv_seconds_since_last_click"));
            assertEquals(713683, jsonObject.getLong("conv_seconds_since_first_imp"));
            assertEquals(10009, jsonObject.getLong("conv_seconds_since_last_imp"));
            assertEquals(703674, jsonObject.getLong("seconds_between_first_last_imp"));
            assertEquals(1443750869, jsonObject.getLong("first_imp_timestamp"));
            assertEquals(1444454543, jsonObject.getLong("last_imp_timestamp"));
            assertEquals("g", jsonObject.getString("first_network"));
            assertEquals("g", jsonObject.getString("last_network"));
            assertEquals("BV2IRUKOLNBNNBRMOCWSMW", jsonObject.getString("first_ad_eid"));
            assertEquals("BV2IRUKOLNBNNBRMOCWSMW", jsonObject.getString("last_ad_eid"));
            assertEquals("ZCHD5KIIXBCWZMBNN37A3D", jsonObject.getString("first_adgroup_eid"));
            assertEquals("ZCHD5KIIXBCWZMBNN37A3D", jsonObject.getString("last_adgroup_eid"));
            assertEquals("[\"g\"]", jsonObject.get("distinct_networks").toString());
            assertEquals("[\"BV2IRUKOLNBNNBRMOCWSMW\"]", jsonObject.get("distinct_ad_eid").toString());
            assertEquals("[\"ZCHD5KIIXBCWZMBNN37A3D\"]", jsonObject.get("distinct_adgroup_eid").toString());
        }
    }
}
