package presto.udfs.scalar;

import static com.facebook.presto.spi.type.VarcharType.VARCHAR;
import static com.facebook.presto.type.TypeJsonUtils.appendToBlockBuilder;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static presto.udfs.scalar.TestUtils.areBlocksEqual;

import com.facebook.presto.spi.block.Block;
import com.facebook.presto.spi.block.BlockBuilder;
import com.facebook.presto.spi.block.BlockBuilderStatus;
import com.facebook.presto.spi.block.InterleavedBlockBuilder;
import com.google.common.collect.ImmutableList;
import io.airlift.slice.Slice;
import io.airlift.slice.Slices;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Iterator;

public class TestJsonFunctions
{
  @Test
  public void testVerifyExtractKeyValueToMap() throws Exception
  {
    String jsonArrayPath = "src/test/resources/TestJSONArray.json";
    try (BufferedReader expectedBuffer = new BufferedReader(
        new InputStreamReader(new FileInputStream(jsonArrayPath)))) {
      String rawJsonInput = expectedBuffer.readLine();
      byte[] byteInput = rawJsonInput.getBytes();
      Slice jsonInput = Slices.wrappedBuffer(byteInput);

      // Build expected output block with correct values
      Block expectedOutput = buildBlockWithList(ImmutableList.of("123", "", "456", "www.adroll.com"));

      // Actual output
      Block actualOutput = JsonFunctions.extractKeyValueToMap(jsonInput, Slices.wrappedBuffer("id".getBytes()),
          Slices.wrappedBuffer("value".getBytes()));

      assertTrue(areBlocksEqual(VARCHAR, expectedOutput, actualOutput));

      // Build expected output block with incorrect values
      expectedOutput = buildBlockWithList(ImmutableList.of("123", "", "46", "www.adroll.com"));

      assertFalse(areBlocksEqual(VARCHAR, expectedOutput, actualOutput));
    }
  }

  private Block buildBlockWithList(ImmutableList contents)
  {
    BlockBuilder blockBuilder = new InterleavedBlockBuilder(
        ImmutableList.of(VARCHAR, VARCHAR), new BlockBuilderStatus(), contents.size());

    Iterator it = contents.listIterator();
    while (it.hasNext()) {
      appendToBlockBuilder(VARCHAR, it.next(), blockBuilder);
    }

    return blockBuilder.build();
  }
}
