package presto.udfs.scalar;

import static org.junit.Assert.assertEquals;
import static com.facebook.presto.testing.TestingConnectorSession.SESSION;

import com.facebook.presto.spi.block.Block;
import com.facebook.presto.spi.type.Type;

public class TestUtils
{
  private TestUtils()
  {
  }

  /**
   * Validate if both blocks are the same
   * @param type
   * @param expected
   * @param actual
   */
  public static boolean areBlocksEqual(Type type, Block expected, Block actual)
  {
    // Check sizes
    assertEquals(expected.getPositionCount(), actual.getPositionCount());
    for (int position = 0; position < actual.getPositionCount(); position++) {
          if (!type.getObjectValue(SESSION, actual, position).equals(
                  type.getObjectValue(SESSION, expected, position))) {
            return false;
          }
    }
    return true;
  }
}
