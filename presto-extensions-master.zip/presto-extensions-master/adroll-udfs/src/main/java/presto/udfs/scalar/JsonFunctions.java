package presto.udfs.scalar;

import static com.facebook.presto.spi.type.VarcharType.VARCHAR;
import static com.facebook.presto.type.TypeJsonUtils.appendToBlockBuilder;

import com.amazonaws.util.json.JSONArray;
import com.amazonaws.util.json.JSONException;
import com.amazonaws.util.json.JSONObject;
import com.facebook.presto.operator.Description;
import com.facebook.presto.operator.scalar.ScalarFunction;
import com.facebook.presto.spi.block.Block;
import com.facebook.presto.spi.block.BlockBuilder;
import com.facebook.presto.spi.block.BlockBuilderStatus;
import com.facebook.presto.spi.block.InterleavedBlockBuilder;
import com.facebook.presto.spi.type.StandardTypes;
import com.facebook.presto.type.SqlType;
import com.google.common.collect.ImmutableList;
import io.airlift.slice.Slice;

public class JsonFunctions
{
  private JsonFunctions()
  {
  }

  /**
   * Returns a map value based on the JSONArray values
   *
   * Example:
   *
   * For JsonArray column `custom_fields` = [{'id':2871, 'value':null}, {'id':2245, 'value':'www.adroll.com'}]
   *
   * Query:
   *   select extract_key_value_to_map(custom_fields, 'id', 'value') from zendesk_custom_snapshots
   *   where date='2016-03-10' limit 1;
   *
   * Output:
   * {'2871'='', '2245'='www.adroll.com'}
   */
  @Description("Returns a map corresponding to the JsonArray input")
  @ScalarFunction("extract_key_value_to_map")
  @SqlType("map<varchar,varchar>")
  public static Block extractKeyValueToMap(@SqlType(StandardTypes.VARCHAR) Slice jsonArraySlice,
                                           @SqlType(StandardTypes.VARCHAR) Slice keyField,
                                           @SqlType(StandardTypes.VARCHAR) Slice valueField)
  {
    String jsonString = jsonArraySlice.toStringUtf8();
    String key = keyField.toStringUtf8();
    String value = valueField.toStringUtf8();
    if (jsonString.isEmpty() || key.isEmpty() || value.isEmpty()) {
      return emptyBlockObject();
    }

    // Get JSONArray of the custom_fields
    JSONArray customFieldsJsonArray;
    try {
      customFieldsJsonArray = new JSONArray(jsonString);
    }
    catch (JSONException e) {
      return emptyBlockObject();
    }

    // Number of expectedEntries for the builder is the (length of the JsonArray) * 2 for each key and value pair in it
    BlockBuilder blockBuilder = new InterleavedBlockBuilder(
        ImmutableList.of(VARCHAR, VARCHAR), new BlockBuilderStatus(), customFieldsJsonArray.length() * 2);

    // Add key/value pair of every custom_field into the block
    try {
      for (int i = 0; i < customFieldsJsonArray.length(); i++) {
        JSONObject currentObj = (JSONObject) customFieldsJsonArray.get(i);
        // No entry in the map if the key doesn't exist
        if (!currentObj.isNull(key)) {
          appendToBlockBuilder(VARCHAR, currentObj.getString(key), blockBuilder);
          appendToBlockBuilder(VARCHAR, currentObj.isNull(value) ? "" : currentObj.getString(value), blockBuilder);
        }
      }
    }
    catch (JSONException | NullPointerException | ClassCastException e) {
      return emptyBlockObject();
    }
    return blockBuilder.build();
  }

  private static Block emptyBlockObject()
  {
    return new InterleavedBlockBuilder(ImmutableList.of(VARCHAR, VARCHAR), new BlockBuilderStatus(), 0).build();
  }
}
