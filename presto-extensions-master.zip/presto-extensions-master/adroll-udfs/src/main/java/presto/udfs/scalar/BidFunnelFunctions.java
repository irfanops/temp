package presto.udfs.scalar;

import com.facebook.presto.operator.Description;
import com.facebook.presto.operator.scalar.ScalarFunction;
import com.facebook.presto.spi.type.StandardTypes;
import com.facebook.presto.type.SqlType;

import java.util.Iterator;

import io.airlift.slice.Slice;
import io.airlift.slice.Slices;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

public final class BidFunnelFunctions
{
    private BidFunnelFunctions()
    {
    }

    /**
     * Returns information on expired segments encountered in the bid funnel.
     *
     * Example:
     *   select expired_segments(bid_funnel_state) from log_lines
     *   where date='2016-04-21' and line_type='bfl' limit 20;
     */
    @Description("Returns information on expired segments encountered in the bid funnel")
    @ScalarFunction("expired_segments")
    @SqlType(StandardTypes.JSON)
    public static Slice expiredSegments(@SqlType(StandardTypes.VARCHAR) Slice bidFunnelState)
    {
        /**
         *  $
         *  ?- campaigns
         *      |- details[]
         *          |- campaign_eid
         *          |- adgroups
         *              |- details[]
         *                  |- adgroup_eid
         *                  |- segments
         *                      |- details[]
         *                          |- segment_id
         *                          ?- no_bids
         *                              |- expired_segment
         *                          ?- meta_data
         *                              |- overdue_seconds
         *
         * ?-: not guaranteed
         *
         */

        String bidFunnelString = bidFunnelState.toStringUtf8();

        if (bidFunnelString.isEmpty()) {
            return Slices.wrappedBuffer(emptyJSONArray());
        }

        JSONArray campaignDetailsJSONArray;

        //String to Json
        try {
            campaignDetailsJSONArray = ((new JSONObject(bidFunnelString)).getJSONObject("campaigns")).getJSONArray("details");
        }
        catch (JSONException e) {
            return Slices.wrappedBuffer(emptyJSONArray());
        }

        JSONArray resultJSONArray = new JSONArray();

        try {
            for (int i = 0; i < campaignDetailsJSONArray.length(); i++) {
                JSONObject campaignJSONObject = campaignDetailsJSONArray.getJSONObject(i);
                String campaignEID;
                try {
                    campaignEID = campaignJSONObject.getString("campaign_eid");
                }
                catch (JSONException e) {
                    campaignEID = "";
                }

                JSONArray adgroupDetailsJSONArray = campaignJSONObject.getJSONObject("adgroups").getJSONArray("details");

                for (int j = 0; j < adgroupDetailsJSONArray.length(); j++) {
                    JSONObject adgroupJSONObject = adgroupDetailsJSONArray.getJSONObject(j);
                    String adgroupEID;
                    try {
                        adgroupEID = adgroupJSONObject.getString("adgroup_eid");
                    }
                    catch (JSONException e) {
                        adgroupEID = "";
                    }

                    JSONArray segmentDetailsJSONArray = adgroupJSONObject.getJSONObject("segments").getJSONArray("details");

                    for (int k = 0; k < segmentDetailsJSONArray.length(); k++) {
                        long expiredSegments = 0;
                        long staleSegments = 0;
                        JSONObject segmentJSONObject = segmentDetailsJSONArray.getJSONObject(k);
                        if (segmentJSONObject.has("no_bids")) {
                            JSONObject segmentNoBidsJSONObject = segmentJSONObject.getJSONObject("no_bids");
                            if (segmentNoBidsJSONObject.has("expired_segment")) {
                                expiredSegments = segmentJSONObject.getJSONObject("no_bids").getInt("expired_segment");
                            }
                            if (segmentNoBidsJSONObject.has("stale_segment")) {
                                staleSegments = segmentJSONObject.getJSONObject("no_bids").getInt("stale_segment");
                            }
                        }
                        else {
                            continue;
                        }
                        String segmentID = segmentJSONObject.getString("segment_id");
                        long overdueSeconds;
                        if (segmentJSONObject.has("meta_data")) {
                            JSONObject metadataJSONObject = segmentJSONObject.getJSONObject("meta_data");
                            if (metadataJSONObject != null && metadataJSONObject.has("overdue_seconds")) {
                                overdueSeconds = metadataJSONObject.getInt("overdue_seconds");
                            }
                            else {
                                continue;
                            }
                        }
                        else {
                            continue;
                        }
                        JSONObject singleResultJSONObject = new JSONObject();
                        singleResultJSONObject.put("campaign_eid", campaignEID);
                        singleResultJSONObject.put("adgroup_eid", adgroupEID);
                        singleResultJSONObject.put("expired_segments", expiredSegments);
                        singleResultJSONObject.put("stale_segments", staleSegments);
                        singleResultJSONObject.put("segment_id", segmentID);
                        singleResultJSONObject.put("overdue_seconds", overdueSeconds);
                        resultJSONArray.put(singleResultJSONObject);
                    }
                }
            }
        }
        catch (Exception e) {
            return Slices.wrappedBuffer(emptyJSONArray());
        }
        byte[] out = resultJSONArray.toString().getBytes();
        return Slices.wrappedBuffer(out);
    }

    /**
     * Given a bid funnel blob, summarizes the numbers of no-bid reasons at the campaign,
     * segment and adgroup levels.
     *
     * Example query:
     * SELECT
     * cookie,
     * no_bid_counts['no_bid_level'] as no_bid_level,
     * no_bid_counts['reason'] as reason,
     * no_bid_counts['no_bids'] as no_bids
     * FROM
     * (
     *  SELECT cookie, bid_funnel_state FROM adroll.log_lines
     *  WHERE date = '2016-05-15' AND line_type='bfl'
     *  AND line_exchange='adx' LIMIT 50
     * )  CROSS JOIN UNNEST(TRY_CAST(no_bid_counts(bid_funnel_state) as ARRAY<MAP<VARCHAR, VARCHAR>>)) AS t(no_bid_counts);
     *
     */
    @Description("Return campaign/segment/adgroup-level no-bid reason counts")
    @ScalarFunction("no_bid_counts")
    @SqlType(StandardTypes.JSON)
    public static Slice NBRCounts(@SqlType(StandardTypes.VARCHAR) Slice bidFunnelState)
    {
        String bidFunnelString = bidFunnelState.toStringUtf8();

        if (bidFunnelString.isEmpty()) {
            return Slices.wrappedBuffer(emptyJSONArray());
        }

        JSONObject funnelStatsJSONObject;

        //String to Json
        try {
            funnelStatsJSONObject = (new JSONObject(bidFunnelString)).getJSONObject("funnel_stats");
        }
        catch (JSONException e) {
            return Slices.wrappedBuffer(emptyJSONArray());
        }

        JSONArray resultJSONArray = new JSONArray();
        Iterator<String> levels = funnelStatsJSONObject.keys();
        while (levels.hasNext()) {
            JSONObject levelJSONObject = funnelStatsJSONObject.getJSONObject(levels.next());
            if (levelJSONObject.has("no_bids")) {
                JSONObject noBidsJSONObject = levelJSONObject.getJSONObject("no_bids");
                Iterator<String> noBidsLevels = noBidsJSONObject.keys();
                while (noBidsLevels.hasNext()) {
                    String noBidsLevel = noBidsLevels.next();
                    JSONObject noBidsLevelJSONObject = noBidsJSONObject.getJSONObject(noBidsLevel);
                    Iterator<String> reasons = noBidsLevelJSONObject.keys();
                    while (reasons.hasNext()) {
                        String reason = reasons.next();
                        long nobids = noBidsLevelJSONObject.getInt(reason);
                        JSONObject singleResultJSONObject = new JSONObject();
                        singleResultJSONObject.put("no_bid_level", noBidsLevel);
                        singleResultJSONObject.put("reason", reason);
                        singleResultJSONObject.put("no_bids", nobids);
                        resultJSONArray.put(singleResultJSONObject);
                    }
                }
            }
        }

        byte[] out = resultJSONArray.toString().getBytes();
        return Slices.wrappedBuffer(out);
    }

    private static byte[] emptyJSONArray()
    {
        return "[]".getBytes();
    }
}
