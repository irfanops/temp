package presto.udfs.scalar;

import com.facebook.presto.operator.Description;
import com.facebook.presto.operator.scalar.ScalarFunction;
import com.facebook.presto.spi.type.StandardTypes;
import com.facebook.presto.type.SqlType;
import core.logs.Logline;
import core.logs.accounting.CostCalculator;
import core.logs.accounting.CostResult;
import core.utils.TimeUtils;
import io.airlift.slice.Slice;
import presto.udfs.UdfUtils;

import javax.annotation.Nullable;

public final class CostFunctions
{
  private CostFunctions()
  {
  }

  private static CostCalculator costCalculator;

  static {
    costCalculator = new CostCalculator();
  }

  /**
   * Returns the cpm field in a log line, decrypting it if necessary.  The return value is in CPI microdollars.
   *
   * Example:
   *   select cpm(cpm, network, type, timestamp) from log_lines where date='2015-03-27' and line_type='imp' limit 20;
   */
  @Description("displays the cpm for a log line")
  @ScalarFunction("cpm")
  @SqlType(StandardTypes.BIGINT)
  public static long cpm(
      @Nullable @SqlType(StandardTypes.VARCHAR) Slice cpm,
      @Nullable @SqlType(StandardTypes.VARCHAR) Slice network,
      @Nullable @SqlType(StandardTypes.VARCHAR) Slice type,
      @Nullable @SqlType(StandardTypes.BIGINT) Long timestamp)
  {
    Logline line = new Logline();
    line.set("cpm", UdfUtils.emptyIfNull(cpm));
    line.set("network", UdfUtils.emptyIfNull(network));
    line.set("type", UdfUtils.emptyIfNull(type));
    line.setTimestamp(timestamp == null ? -1L : TimeUtils.timestampToLong(timestamp));
    CostResult cost = new CostResult();
    // Convert to the units that we eventually surface in the CostResult object at the end of cost calculation
    // so as to not confuse people who use also look at the bid_costs table.
    double cpmValue;
    synchronized (costCalculator) {
      cpmValue = costCalculator.getCpmForAnyLine(line, cost);
    }
    double cpiMicros = CostCalculator.dollarsToMicrodollars(CostCalculator.cpmToCpi(cpmValue));
    return Math.round(cpiMicros);
  }
}
