package presto.udfs;

import com.facebook.presto.metadata.FunctionFactory;
import com.facebook.presto.metadata.FunctionListBuilder;
import com.facebook.presto.metadata.SqlFunction;
import com.facebook.presto.spi.type.TypeManager;
import presto.udfs.scalar.BidFunnelFunctions;
import presto.udfs.scalar.ConversionFunctions;
import presto.udfs.scalar.CostFunctions;
import presto.udfs.scalar.JsonFunctions;
import presto.udfs.scalar.TrackableFunctions;
import presto.udfs.scalar.UserAgentFunctions;
import presto.udfs.scalar.OpenRTBFunctions;

import java.util.List;

public class UdfFactory implements FunctionFactory
{
  private final TypeManager typeManager;

  public UdfFactory(TypeManager typeManager)
  {
    this.typeManager = typeManager;
  }

  @Override
  public List<SqlFunction> listFunctions()
  {
    return new FunctionListBuilder(typeManager)
        .scalar(CostFunctions.class)
        .scalar(UserAgentFunctions.class)
        .scalar(TrackableFunctions.class)
        .scalar(ConversionFunctions.class)
        .scalar(JsonFunctions.class)
        .scalar(BidFunnelFunctions.class)
        .scalar(OpenRTBFunctions.class)
        .getFunctions();
  }
}
