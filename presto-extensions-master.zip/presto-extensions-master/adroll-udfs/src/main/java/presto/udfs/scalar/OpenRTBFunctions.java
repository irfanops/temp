package presto.udfs.scalar;

import com.facebook.presto.operator.Description;
import com.facebook.presto.operator.scalar.ScalarFunction;
import com.facebook.presto.spi.type.StandardTypes;
import com.facebook.presto.type.SqlType;
import io.airlift.slice.Slice;
import io.airlift.slice.Slices;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import org.apache.commons.lang3.StringUtils;
import java.util.Collections;
import java.util.ArrayList;

public final class OpenRTBFunctions
{
    private OpenRTBFunctions() {}

    /**
     * Parses and combines various OpenRTB native asset fields from bid lines / joined_log_lines
     * into a single JSON object, keyed by asset type.
     *
     * Example:
     *   select parse_native_assets(openrtb_native_request_assets_id,
     *       openrtb_native_request_assets_required,
     *       openrtb_native_request_assets_title_len,
     *       openrtb_native_request_assets_img_type,
     *       openrtb_native_request_assets_img_wmin,
     *       openrtb_native_request_assets_img_hmin,
     *       openrtb_native_request_assets_data_type,
     *       openrtb_native_request_assets_data_len,
     *       openrtb_native_request_assets_img_wxh,
     *       openrtb_native_request_assets_img_mimes) from adroll.log_lines
     *   where date='2017-12-23' and line_type='bid' and line_exchange='bsw' and inventory_source='n' limit 1;
     *
     *
     * Example output:
     *
     * {
        "title":{
            "len": "100",
            "local_id": 1,
            "required": 1
         },
        "img_2":{
             "local_id": 3,
             "wxh": "null",
             "hmin": "25",
             "wmin": "25",
             "required": 0,
             "mimes": "null"
         },
         "data_2":{
             "local_id": 4,
             "len": "300",
             "required": 1
         },
         "img_3":{
             "local_id": 2,
             "wxh": "600x500",
             "hmin": "375",
             "wmin": "450",
             "required": 1,
             "mimes": "null"
         },
         "data_1": {
             "local_id": 5,
             "len": "30",
             "required": 1
        }
        }
     */

    @Description("Parses and combines various OpenRTB native asset fields from bid lines into a single JSON object")
    @ScalarFunction("parse_native_assets")
    @SqlType(StandardTypes.JSON)
    public static Slice parse_native_assets(@SqlType(StandardTypes.VARCHAR) Slice id,
                                             @SqlType(StandardTypes.VARCHAR) Slice required,
                                             @SqlType(StandardTypes.VARCHAR) Slice titleLen,
                                             @SqlType(StandardTypes.VARCHAR) Slice imgType,
                                             @SqlType(StandardTypes.VARCHAR) Slice imgWMin,
                                             @SqlType(StandardTypes.VARCHAR) Slice imgHMin,
                                             @SqlType(StandardTypes.VARCHAR) Slice dataType,
                                             @SqlType(StandardTypes.VARCHAR) Slice dataLen,
                                             @SqlType(StandardTypes.VARCHAR) Slice imgWXH,
                                             @SqlType(StandardTypes.VARCHAR) Slice imgMIMEs)
    {
        String idArrayString = id.toStringUtf8();
        if (idArrayString.isEmpty()) {
            return Slices.wrappedBuffer(emptyJSONObject());
        }
        String requiredArrayString = required.toStringUtf8();
        String titleLenArrayString = titleLen.toStringUtf8();
        String imgTypeArrayString = imgType.toStringUtf8();
        String imgWMinArrayString = imgWMin.toStringUtf8();
        String imgHMinArrayString = imgHMin.toStringUtf8();
        String dataTypeArrayString = dataType.toStringUtf8();
        String dataLenArrayString = dataLen.toStringUtf8();
        String imgWXHArrayString = imgWXH.toStringUtf8();
        String imgMIMEsArrayString = imgMIMEs.toStringUtf8();

        JSONArray idArray;
        JSONArray requiredArray;
        JSONArray titleLenArray;
        JSONArray imgTypeArray;
        JSONArray imgWMinArray;
        JSONArray imgHMinArray;
        JSONArray dataTypeArray;
        JSONArray dataLenArray;
        JSONArray imgWXHArray;
        JSONArray imgMIMEsArray;

        JSONObject outputJson = new JSONObject();

        //String to Json
        try {
            idArray = new JSONArray(idArrayString);
            requiredArray = new JSONArray(requiredArrayString);
            titleLenArray = new JSONArray(titleLenArrayString);
            imgTypeArray = new JSONArray(imgTypeArrayString);
            imgWMinArray = new JSONArray(imgWMinArrayString);
            imgHMinArray = new JSONArray(imgHMinArrayString);
            dataTypeArray = new JSONArray(dataTypeArrayString);
            dataLenArray = new JSONArray(dataLenArrayString);
            imgWXHArray = new JSONArray(imgWXHArrayString);
            imgMIMEsArray = new JSONArray(imgMIMEsArrayString);
        }
        catch (JSONException e) {
            outputJson.put("error", e.toString());
            return Slices.wrappedBuffer(outputJson.toString().getBytes());
        }

        // iterate over all asset arrays simultaneously and construct JSON for asset at each index,
        // determining asset supertype by presence of either title length, data type, or image type

        for (int i = 0; i < idArray.length(); i++) {
            JSONObject assetJson = new JSONObject();

            String titleLenString = titleLenArray.get(i).toString();
            String dataTypeIDString = dataTypeArray.get(i).toString();
            String imgTypeIDString = imgTypeArray.get(i).toString();

            if (!("null".equals(titleLenString))) {
                assetJson.put("len", titleLenString);
                assetJson.put("local_id", idArray.get(i));
                assetJson.put("required", requiredArray.get(i));
                outputJson.put("title", assetJson);
            }

            else if (!("null".equals(imgTypeIDString))) {
                assetJson.put("local_id", idArray.get(i));
                assetJson.put("required", requiredArray.get(i));
                assetJson.put("hmin", imgHMinArray.get(i).toString());
                assetJson.put("wmin", imgWMinArray.get(i).toString());
                assetJson.put("wxh", imgWXHArray.get(i).toString());
                assetJson.put("mimes", imgMIMEsArray.get(i).toString());
                outputJson.put("img_" + imgTypeIDString, assetJson);
            }

            else if (!("null".equals(dataTypeIDString))) {
                assetJson.put("local_id", idArray.get(i));
                assetJson.put("required", requiredArray.get(i));
                assetJson.put("len",  dataLenArray.get(i).toString());
                outputJson.put("data_" + dataTypeIDString, assetJson);
            }
        }

        byte[] out = outputJson.toString().getBytes();
        return Slices.wrappedBuffer(out);
    }

    /**
     * Return a JSON object containing the list of native img/data asset types supported by the imp object
     * on the given bid line, along with their supertype and whether optional or required.
     *
     * Example:
     *   select parse_native_asset_types(openrtb_native_request_assets_required,
     *       openrtb_native_request_assets_img_type,
     *       openrtb_native_request_assets_data_type) from adroll.log_lines
     *   where date='2017-12-23' and line_type='bid' and line_exchange='bsw' and inventory_source='n' limit 1;
     *
     * Example output:
     *
     *  {"img":{"optional":"2","required":"3"},"data":{"optional":"","required":"1,2"}}
     *
     */

    @Description("Return a JSON object containing the list of native img/data asset types supported by this bid's imp object")
    @ScalarFunction("parse_native_asset_types")
    @SqlType(StandardTypes.JSON)
    public static Slice parse_native_asset_types(@SqlType(StandardTypes.VARCHAR) Slice required,
                                            @SqlType(StandardTypes.VARCHAR) Slice imgType,
                                            @SqlType(StandardTypes.VARCHAR) Slice dataType)
    {
        String requiredArrayString = required.toStringUtf8();
        if (requiredArrayString.isEmpty()) {
            return Slices.wrappedBuffer(emptyJSONObject());
        }
        String imgTypeArrayString = imgType.toStringUtf8();
        String dataTypeArrayString = dataType.toStringUtf8();

        JSONArray requiredArray;
        JSONArray imgTypeArray;
        JSONArray dataTypeArray;

        JSONObject outputJson = new JSONObject();

        //String to Json
        try {
            requiredArray = new JSONArray(requiredArrayString);
            imgTypeArray = new JSONArray(imgTypeArrayString);
            dataTypeArray = new JSONArray(dataTypeArrayString);
        }
        catch (JSONException e) {
            outputJson.put("error", e.toString());
            return Slices.wrappedBuffer(outputJson.toString().getBytes());
        }

        ArrayList<String> requiredDataArray = new ArrayList<String>();
        ArrayList<String> optionalDataArray = new ArrayList<String>();
        ArrayList<String> requiredImgArray = new ArrayList<String>();
        ArrayList<String> optionalImgArray = new ArrayList<String>();

        for (int i = 0; i < requiredArray.length(); i++) {
            String requiredString = requiredArray.get(i).toString();
            String dataTypeIDString = dataTypeArray.get(i).toString();
            String imgTypeIDString = imgTypeArray.get(i).toString();

            if (!("null".equals(imgTypeIDString))) {
                if ("1".equals(requiredString)) {
                    requiredImgArray.add(imgTypeIDString);
                }

                else {
                    optionalImgArray.add(imgTypeIDString);
                }
            }

            else if (!("null".equals(dataTypeIDString))) {
                if ("1".equals(requiredString)) {
                    requiredDataArray.add(dataTypeIDString);
                }

                else {
                    optionalDataArray.add(dataTypeIDString);
                }
            }
        }

        Collections.sort(requiredDataArray);
        Collections.sort(optionalDataArray);
        Collections.sort(requiredImgArray);
        Collections.sort(optionalImgArray);

        JSONObject outputDataJson = new JSONObject();
        JSONObject outputImgJson = new JSONObject();

        outputDataJson.put("required", StringUtils.join(requiredDataArray, ','));
        outputDataJson.put("optional", StringUtils.join(optionalDataArray, ','));
        outputImgJson.put("required", StringUtils.join(requiredImgArray, ','));
        outputImgJson.put("optional", StringUtils.join(optionalImgArray, ','));

        outputJson.put("data", outputDataJson);
        outputJson.put("img", outputImgJson);

        byte[] out = outputJson.toString().getBytes();
        return Slices.wrappedBuffer(out);
    }

    private static byte[] emptyJSONObject()
    {
        return "{}".getBytes();
    }
}
