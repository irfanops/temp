package presto.udfs.scalar;

import com.facebook.presto.operator.Description;
import com.facebook.presto.operator.scalar.ScalarFunction;
import com.facebook.presto.spi.block.Block;
import com.facebook.presto.spi.block.BlockBuilder;
import com.facebook.presto.spi.block.BlockBuilderStatus;
import com.facebook.presto.spi.block.InterleavedBlockBuilder;
import com.facebook.presto.spi.type.StandardTypes;
import com.facebook.presto.type.SqlType;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import io.airlift.slice.Slice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ua_parser.Client;
import ua_parser.Parser;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import static com.facebook.presto.spi.type.VarcharType.VARCHAR;
import static com.facebook.presto.type.TypeJsonUtils.appendToBlockBuilder;
import static presto.udfs.UdfUtils.emptyIfNull;

public final class UserAgentFunctions
{
  public static final Logger LOG = LoggerFactory.getLogger(UserAgentFunctions.class);

  private static final int CACHE_SIZE = 1_000_000;
  private static final int CACHE_EXPIRATION = 20;
  private static final int INITIAL_CAPACITY = 65_536;
  private static final int CONCURRENCY = 16;

  private static Parser parser;
  private static LoadingCache<String, Block> cache;
  private static Block emptyBlock;

  static {
    try {
      parser = new Parser();
      cache = createCache();
      emptyBlock = userAgentToBlock("", "", "", "", "");
    }
    catch (IOException e) {
      LOG.error("Could not load user agent parser", e);
    }
  }

  private UserAgentFunctions()
  {
  }

  protected static LoadingCache<String, Block> createCache()
  {
    return CacheBuilder.newBuilder()
                       .maximumSize(CACHE_SIZE)
                       .expireAfterAccess(CACHE_EXPIRATION, TimeUnit.MINUTES)
                       .initialCapacity(INITIAL_CAPACITY)
                       .concurrencyLevel(CONCURRENCY)
                       .build(new CacheLoader<String, Block>()
                       {
                         @Override
                         public Block load(String userAgent)
                         {
                           return loadUserAgent(userAgent);
                         }
                       });
  }

  protected static Block loadUserAgent(String userAgent)
  {
    Client c = parser.parse(userAgent);

    String os = c.os.family;
    String device = c.device.family;
    String userAgentFamily = c.userAgent.family;
    String userAgentVersion = c.userAgent.major;
    String osVersion = ((c.os.major != null) ? c.os.major : "") + ((c.os.minor != null) ? ("." + c.os.minor) : "");

    return userAgentToBlock(os, device, userAgentFamily, userAgentVersion, osVersion);
  }

  protected static Block userAgentToBlock(String os,
                                          String device,
                                          String userAgentFamily,
                                          String userAgentVersion,
                                          String osVersion)
  {
    Map<String, String> map = ImmutableMap.<String, String>of(
        "os", emptyIfNull(os),
        "device", emptyIfNull(device),
        "user_agent", emptyIfNull(userAgentFamily),
        "user_agent_version", emptyIfNull(userAgentVersion),
        "os_version", emptyIfNull(osVersion));

    BlockBuilder blockBuilder = new InterleavedBlockBuilder(ImmutableList.of(VARCHAR, VARCHAR), new BlockBuilderStatus(), map.size() * 2);
    for (Entry<String, String> entry : map.entrySet()) {
        appendToBlockBuilder(VARCHAR, entry.getKey(), blockBuilder);
        appendToBlockBuilder(VARCHAR, entry.getValue(), blockBuilder);
    }
    return blockBuilder.build();
  }

  /**
   * For a given user_agent string, parses out the OS, device, user agent family, and user agent major version
   *
   * Example:
   *   select parse_ua(user_agent) from log_lines where date='2015-03-27' and line_type='imp' limit 20;
   */
  @Description("Displays a parsed user agent for a log line")
  @ScalarFunction("parse_ua")
  @SqlType("map<varchar,varchar>")
  public static Block parseUserAgent(@SqlType(StandardTypes.VARCHAR) Slice userAgent)
  {
    try {
      return cache.get(userAgent.toStringUtf8());
    }
    catch (ExecutionException e) {
      LOG.error("Error parsing user agent string {}", userAgent, e);
      cache.put(userAgent.toStringUtf8(), emptyBlock);
      return emptyBlock;
    }
  }
}
