package presto.udfs.scalar;

import com.facebook.presto.operator.Description;
import com.facebook.presto.operator.scalar.ScalarFunction;
import com.facebook.presto.spi.type.StandardTypes;
import com.facebook.presto.type.SqlType;

import io.airlift.slice.Slice;
import io.airlift.slice.Slices;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.util.HashSet;
import java.util.Set;

public final class ConversionFunctions
{
    private ConversionFunctions() {}

    /**
     * Returns metrics based on a conversion's site history
     *
     * Example:
     *   select site_history_mapping(site_history) from log_lines
     *   where date='2015-03-27' and line_type='ct2' limit 20;
     */
    @Description("Returns metrics based on a conversion's site history")
    @ScalarFunction("site_history_mapping")
    @SqlType(StandardTypes.JSON)
    public static Slice siteHistoryMapping(@SqlType(StandardTypes.VARCHAR) Slice siteHistory,
                                           @SqlType(StandardTypes.BIGINT) long conversionTimestamp)
    {
        String siteHistoryString = siteHistory.toStringUtf8();

        if (siteHistoryString.isEmpty()) {
            return Slices.wrappedBuffer(emptyJSONObject());
        }

        JSONArray siteHistoryArray;

        //String to Json
        try {
            siteHistoryArray = new JSONArray(siteHistoryString);
        }
        catch (JSONException e) {
            return Slices.wrappedBuffer(emptyJSONObject());
        }

        // Raw columns used
        String adEid;
        String adGroupEid;
        String domain;
        String network;
        String rawTimestamp;
        String type;

        // List of metrics calculated
        int numImps = 0;
        int numClicks = 0;
        long convSecondsSinceFirstClick;
        long convSecondsSinceLastClick;
        long convSecondsSinceFirstImp;
        long convSecondsSinceLastImp;
        long secondsBetweenFirstAndLastImp;
        long firstImpTimestamp = -1;
        long lastImpTimestamp = -1;
        String firstDomain = "";
        String lastDomain = "";
        String firstNetwork = "";
        String lastNetwork = "";
        String lastClickDomain = "";
        String lastClickNetwork = "";
        String firstAdEid = "";
        String lastAdEid = "";
        String firstAdGroupEid = "";
        String lastAdGroupEid = "";
        Set<String> listDomains = new HashSet<>();
        Set<String> listNetworks = new HashSet<>();
        Set<String> listAdEid = new HashSet<>();
        Set<String> listAdGroupEid = new HashSet<>();

        // Helpers
        long timestamp;
        long firstClickTimestamp = -1;
        long lastClickTimestamp = -1;

        // Iterate over the array and perform metrics
        try {
            for (int i = 0; i < siteHistoryArray.length(); i++) {
                JSONObject jsonObject = (JSONObject) siteHistoryArray.get(i);

                // Raw Gets
                adEid = jsonObject.optString("ad_eid", "");
                adGroupEid = jsonObject.optString("adgroup_eid", "");
                domain = jsonObject.optString("domain", "");
                network = jsonObject.optString("network", "");
                rawTimestamp = jsonObject.optString("timestamp", "");
                type = jsonObject.optString("type", "");

                // Transforming raw segments
                timestamp = Long.parseLong(rawTimestamp);

                // Perform Metric Analysis
                firstImpTimestamp = ("imp".equals(type) && firstImpTimestamp == -1) ? timestamp : firstImpTimestamp;
                lastImpTimestamp = ("imp".equals(type)) ? timestamp : lastImpTimestamp;

                firstClickTimestamp = ("cli".equals(type) && firstClickTimestamp == -1) ? timestamp : firstClickTimestamp;
                lastClickTimestamp = ("cli".equals(type)) ? timestamp : lastClickTimestamp;

                if ("imp".equals(type)) {
                    numImps++;
                }

                if ("cli".equals(type)) {
                    numClicks++;
                    lastClickDomain = domain.isEmpty() ? lastClickDomain : domain;
                    lastClickNetwork = network.isEmpty() ? lastClickNetwork : network;
                }

                firstDomain = firstDomain.isEmpty() ? domain : firstDomain;
                firstNetwork = firstNetwork.isEmpty() ? network : firstNetwork;
                firstAdEid = firstAdEid.isEmpty() ? adEid : firstAdEid;
                firstAdGroupEid = firstAdGroupEid.isEmpty() ? adGroupEid : firstAdGroupEid;

                lastDomain = domain.isEmpty() ? lastDomain : domain;
                lastNetwork = network.isEmpty() ? lastNetwork : network;
                lastAdEid = adEid.isEmpty() ? lastAdEid : adEid;
                lastAdGroupEid = adGroupEid.isEmpty() ? lastAdGroupEid : adGroupEid;
                listDomains.add(domain);
                listAdEid.add(adEid);
                listAdGroupEid.add(adGroupEid);
                listNetworks.add(network);
            }
        }
        catch (NullPointerException | ClassCastException e) {
            return Slices.wrappedBuffer(emptyJSONObject());
        }
        conversionTimestamp = normalizeTimestamp(conversionTimestamp);
        firstClickTimestamp = normalizeTimestamp(firstClickTimestamp);
        lastClickTimestamp = normalizeTimestamp(lastClickTimestamp);
        firstImpTimestamp = normalizeTimestamp(firstImpTimestamp);
        lastImpTimestamp = normalizeTimestamp(lastImpTimestamp);

        convSecondsSinceFirstClick = (firstClickTimestamp != -1) ? conversionTimestamp - firstClickTimestamp : -1;
        convSecondsSinceLastClick = (lastClickTimestamp != -1) ? conversionTimestamp - lastClickTimestamp : -1;
        convSecondsSinceFirstImp = (firstImpTimestamp != -1) ? conversionTimestamp - firstImpTimestamp : -1;
        convSecondsSinceLastImp = (lastImpTimestamp != -1) ? conversionTimestamp - lastImpTimestamp : -1;
        secondsBetweenFirstAndLastImp = (lastImpTimestamp != -1) ? lastImpTimestamp - firstImpTimestamp : -1;

        JSONObject jsonOutput = new JSONObject();
        jsonOutput.put("num_impressions", numImps);
        jsonOutput.put("num_clicks", numClicks);
        jsonOutput.put("conv_seconds_since_first_click", finalTimestampWrapper(convSecondsSinceFirstClick));
        jsonOutput.put("conv_seconds_since_last_click", finalTimestampWrapper(convSecondsSinceLastClick));
        jsonOutput.put("conv_seconds_since_first_imp", finalTimestampWrapper(convSecondsSinceFirstImp));
        jsonOutput.put("conv_seconds_since_last_imp", finalTimestampWrapper(convSecondsSinceLastImp));
        jsonOutput.put("seconds_between_first_last_imp", finalTimestampWrapper(secondsBetweenFirstAndLastImp));
        jsonOutput.put("first_imp_timestamp", finalTimestampWrapper(firstImpTimestamp));
        jsonOutput.put("last_imp_timestamp", finalTimestampWrapper(lastImpTimestamp));
        jsonOutput.put("first_domain", firstDomain);
        jsonOutput.put("last_domain", lastDomain);
        jsonOutput.put("first_network", firstNetwork);
        jsonOutput.put("last_network", lastNetwork);
        jsonOutput.put("last_click_domain", lastClickDomain);
        jsonOutput.put("last_click_network", lastClickNetwork);
        jsonOutput.put("first_ad_eid", firstAdEid);
        jsonOutput.put("last_ad_eid", lastAdEid);
        jsonOutput.put("first_adgroup_eid", firstAdGroupEid);
        jsonOutput.put("last_adgroup_eid", lastAdGroupEid);
        jsonOutput.put("distinct_domains", listDomains);
        jsonOutput.put("distinct_networks", listNetworks);
        jsonOutput.put("distinct_ad_eid", listAdEid);
        jsonOutput.put("distinct_adgroup_eid", listAdGroupEid);
        byte[] out = jsonOutput.toString().getBytes();
        return Slices.wrappedBuffer(out);
    }

    private static long normalizeTimestamp(long timestamp)
    {
        if (timestamp >= 1e12) {
            timestamp = timestamp / 1000;
        }
        return timestamp;
    }
    private static String finalTimestampWrapper(long timestamp)
    {
        if (timestamp == -1) {
            return "";
        }
        else {
            return String.valueOf(timestamp);
        }
    }
    private static byte[] emptyJSONObject()
    {
        return "{}".getBytes();
    }
}
