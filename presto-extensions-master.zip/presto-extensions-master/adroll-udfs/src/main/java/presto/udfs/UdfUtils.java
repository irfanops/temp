package presto.udfs;

import io.airlift.log.Logger;
import io.airlift.slice.Slice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public final class UdfUtils
{
  private UdfUtils()
  {
  }

  private static final Logger LOG = Logger.get(UdfUtils.class);
  private static Connection connection;
  private static final Object connectionLock = new UdfUtils();

  public static Connection getConnection()
  {
    if (connection == null) {
      synchronized (connectionLock) {
        if (connection == null) {
          Properties props = new Properties();
          props.put("user", "presto");
          props.put("ApplicationName", "presto_udfs");

          try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection("jdbc:postgresql://" + "localhost" + ":6432/" + "prodinado", props);
          }
          catch (ClassNotFoundException e) {
            LOG.error("Failed to load sql driver", e);
          }
          catch (SQLException e) {
            LOG.error("Failed to connect to sql", e);
          }
        }
      }
    }
    return connection;
  }

  public static String emptyIfNull(Slice s)
  {
    return s == null ? "" : s.toStringUtf8();
  }

  public static String emptyIfNull(String s)
  {
    return s == null ? "" : s;
  }
}
