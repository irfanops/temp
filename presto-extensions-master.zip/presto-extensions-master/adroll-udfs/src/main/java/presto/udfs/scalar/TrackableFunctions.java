package presto.udfs.scalar;

import com.facebook.presto.operator.Description;
import com.facebook.presto.operator.scalar.ScalarFunction;
import com.facebook.presto.spi.type.StandardTypes;
import com.facebook.presto.type.SqlType;
import io.airlift.slice.Slice;

public final class TrackableFunctions
{
    private TrackableFunctions() {}
    /**
     * For a given cookie, returns whether or not the cookie can be targeted with ads
     *
     * Example:
     *   select trackable(is_trackable, trusted_third_party_cookie) from log_lines
     *   where date='2015-03-27' and line_type='imp' limit 20;
     */
    @Description("Returns true if a cookie can be targeted with ads")
    @ScalarFunction("trackable")
    @SqlType(StandardTypes.BOOLEAN)
    public static boolean trackable(@SqlType(StandardTypes.VARCHAR) Slice isTrackable,
                                    @SqlType(StandardTypes.VARCHAR) Slice trustedThirdPartyCookie)
    {
        String trackable = isTrackable.toStringUtf8();
        String trustedThirdParty = trustedThirdPartyCookie.toStringUtf8();
        return "t".equals(trackable) || (!"f".equals(trackable) && "t".equals(trustedThirdParty));
    }
}
